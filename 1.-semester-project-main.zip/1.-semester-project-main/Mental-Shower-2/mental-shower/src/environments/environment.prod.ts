export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyBWtGD4mRq9YIkP51kXywNHcgO1XYI8TxM",
    authDomain: "mental-shower-2.firebaseapp.com",
    projectId: "mental-shower-2",
    storageBucket: "mental-shower-2.appspot.com",
    messagingSenderId: "775112176105",
    appId: "1:775112176105:web:047d2da40b62b80ca69b78",
    measurementId: "G-1NKSSYDFY3"
  }
};
